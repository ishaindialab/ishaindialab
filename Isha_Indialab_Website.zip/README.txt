# Isha Indialab Website
Static responsive website for Isha Indialab.

Files:
- index.html
- style.css
- script.js

How to use:
1. Upload all three files to your hosting public_html folder.
2. Point your domain to the hosting.
3. Replace any placeholder/contact details if needed.
4. The enquiry form opens WhatsApp to +91 88188 86177.

The site is mobile responsive and does not require a database.
