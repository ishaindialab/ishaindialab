function toggleMenu(){document.getElementById('navlinks').classList.toggle('open')}
document.querySelectorAll('#navlinks a').forEach(a=>a.addEventListener('click',()=>document.getElementById('navlinks').classList.remove('open')));
document.getElementById('year').textContent=new Date().getFullYear();
function sendWhatsApp(e){
  e.preventDefault();
  const n=document.getElementById('name').value;
  const c=document.getElementById('company').value;
  const p=document.getElementById('phone').value;
  const r=document.getElementById('requirement').value;
  const m=document.getElementById('message').value;
  const text=`Hello Isha Indialab,%0A%0AName: ${encodeURIComponent(n)}%0ACompany: ${encodeURIComponent(c)}%0AMobile: ${encodeURIComponent(p)}%0ARequirement: ${encodeURIComponent(r)}%0AMessage: ${encodeURIComponent(m)}`;
  window.open(`https://wa.me/918818886177?text=${text}`,'_blank');
}